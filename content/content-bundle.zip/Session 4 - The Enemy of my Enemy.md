**Session 4 - The Enemy of my Enemy**
*20th of Luck, Year 937*

Upon returning down the hole to the Duergar gatehouse, they found it has been reinforced.

At the gate they were welcomed by the Duergar king, along with a contingent of Duergar stoneguard and Kavalrachni (Duergar Spider Riders)

When they spoke to the duergar king, he mentioned that the city had intruders and that they have had an ongoing feud with the Mindflayers that devistated the city.

The Duergar king offered to return the towns people they still had, if the party assisted in making sure no more Mindflayers made thier way back into the city and to go deeper to the mindflayer colony to put an end to it.

After striking a deal with the duergar king, they were escorted into outskirts of the city into the Steeder pits to meeting a few of the townsfolk held here including Sarza, Randel Odd & Edd.

They decended into the city, moving past most of the towers with minimal encounters. However they did witness a group of duergar burning and torturing a wounded mindflayer.

The party witnessed a large, winged, demonic creature fleeing deeper into the city, attempting to destroy one of the stone towers on the way, at which point all of them started to announce their War song.

As the party descended deeper into the city, Duergar could be see fighting against  Demonic soldiers (Merregon) and eventually joined in the fight.