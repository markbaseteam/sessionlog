**Session 7 - Deep Trouble**
*21st-23rd of Luck, Year 937*

The fight was long and arduous, but the party prevailed, unfortunately losing one of their own in the process. Pander was killed by the Devil, who used some kind of spell to draw the life force from his unconscious body. When he passed, his physical body seeped shadows, dissolving and dissipating into the air, leaving his robes behind which Don promptly collected.

The party managed to defeat the Nycaloth, Korrack splitting in half, bisecting the fiend, causing him to drop the mummified foot of Harrison. At the top of the Devils chamber, they found Gareth, the head of the mining guild from Deepiron. 

Upon existing the chamber and having a long rest, they stumbled across a door they hadn't noticed before. After some investigation, they put one of the leeches on Gareth, his new psychic presence making the door open. 

Within they found a war room of sorts, detailing the movements and locations of other settlements in the underdark. They also saw a large constellation mural on the wall, focusing on the infinity symbol. They also encountered some kind of undead who was filled with thousands of strange worms that lunged out of the body, held back by the thick material that made up the chamber.

They safely made their way from the colony, rescuing the remaining townspeople and gathered some more information on the state of the Duergar city. With their king dead they are both grieving and celebrating the elimination of the Illithid threat, negotiations underway to vote for a new leader.

When they made their way to the surface, they were greeted with some joyful celebrations, life had seemed to return to the small town, Isabelle rewarded them with 800gp worth of coin, jewelry and gems. 

Some of the mercenaries that had flocked to the town were already starting to leave, some of them discussing going over to Ebresia to fight in the war, or heading west towards Guundig. Among this group they also met a new travelling companion, Mitango, a Tabaxi Rogue.

Don's bedsheets had been torn by long claws over night with no trace as to how or why.

We left them leaving the town, heading south-west, in the search for more work.