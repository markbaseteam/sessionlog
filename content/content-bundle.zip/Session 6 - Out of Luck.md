**Session 6 - Out of Luck**
*21st of Luck, Year 937*

Pander fought hard to try and escape with Harrison's dead body, however the Pale Mindflayer took particular interest in the Harengon Bard, opting to take the corpse with him when he disappeared through the casting of a spell.

The rest of the party along with the Kenku Bard & the remaining Duergar found Pander meditating in front of the destroyed and decaying elder brain, where he informed them of Harrison's fate.

Upon going deeper into the Mindflayers colony, they fell into a Pool of brine filled with Tadpoles. Don had one swim up into his brain, however due to Pander & his quick thinking, they managed to kill it with a use of shocking grasp.

Spying on the party was a Duergar that had a leech attached to his temple. Pander fried it, causing the dwarf to fall over in a seizure, dying soon after. On him they found a bag of leeches, a survival mantle and a strange hilt of a blade. Pander immolated the leeches.

Investigating some of the Illithid libraries, they found dozens of creatures, dissected and experimented on, in addition to hundreds if not thousands of jars, containing the parts of various species. They found an injured Mindflayers, attempting to take the rarer components and smuggling then using a Bag of Holding. Don quickly dispatched the Illithid, Korrack claiming the Bag for the party.

They came across the Mindflayers dungeon, where some figures were held.
A Quaggoth and a Dog were growling at each other before being calmed.
The party were introduced to Aric & his pet Gir, Teej's new character. After a successful animal handling check, the Quaggoth became an ally.

They also came across a middle aged human, who they didn't get the name of. He used the leech on his temple to communicate telepathically with members of the party. After coming to an agreement, Don managed to remove it like a surgeon does a tumor, causing minimal harm to the man.

Beyond an illusory wall in the dungeon, they found a storage and rest area, where they found some magical weapons, another strange hilt and survival mantle, gold and another pack of leeches.

Down a long tunnel there was a group of Merregon guarding the entrance to the Devil's lair. This devil invited Pander to 'make a deal' but in a blind rage, Pander flew right into the Devil's lair, leading to a bloody fight.

Some members of the party were injured, the Quaggoth that accompanied them was slaughtered, but with the aid of the Duergar, they managed to kill all of the Merregon guards with no casualties but a few wounds.

The party and Duergar rushed to the Devil's lair to aid Pander, vastly outnumbering the clear leader of this fiendish incursion. However, another Devil was commanded to join the fray.

At the entrance of the Lair, in a puff of flame and smoke, a familiar, rotund Devil stands tall, snarling with it's great axe, a familiar rabbit's food hanging from his neck.

Initiative has yet to be rolled.