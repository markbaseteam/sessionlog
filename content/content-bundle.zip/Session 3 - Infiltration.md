**Session 3 - Infiltration**
**Date**
*19th of Luck, Year 937*

Descending into the Duergar city, the encountered people in various states of work, rest & celebration.

They saw a serious of 5 stone towers that lead deeper into the city, these towers doubled as way to alert the city.

The party attempted to kill the duegar at the bottom of the first tower, one of them making their way inside and reaching the top, managing to blow a horn and alert the city of intruders.

The party killed the two duergar within the tower before making their escape.

They left the duergar city returning to the town.

After spending some time in town, the decided to investigate where they left the messenger guard that they encountered in Session 1. Finding the ropes binding him had been cut and scattered.