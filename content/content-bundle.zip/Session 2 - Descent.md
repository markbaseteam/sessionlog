**Session 2 - Descent**
*18th-19th of Luck, Year 937*

They went deeper into the cave, negotiating with the Goblins to leave peacefully in return for their lives.

The goblins left the cave peacefully, letting the party go foward without any combat.

The party encountered the leader of the Goblin/Bugbear forces, a Goblin named Ba'Sar.

During a fight Ba'Sar revealed himself to be a Barghest but he and his bugbear guards were defeated.

They rescued a selection of townsfolk held in a cage within Ba'Sars chamber, including the owner of Jorges Forge, Jorge.

The party decended into the hole within the chamber, landing in the water below.

Exploring the cavern that they landed in, upon reaching the shore they came across a large stone gate what was well built and fortified.

Infiltrating the gate they killed the 2 duergar that were guarding it.

This gate was revealed to be a duergar construction, and entrance to their city.


#players 