**Session 1 - Arrival**
*17th-18th of Luck, Year 937*

The players formed a party and were travelling together using a Cart.

Along the road they encountered a guard that was carrying a message from the Town Captain, asking for aide.

Assaulted, tied up and robbed Guard who was sent as a messenger.

Upon entering the town they were ambushed by Grub & Kent, two of the last remaining guards within the town.

Offered gold in return for Goblin Ears & Bugbear tails by the Isabelle, the Guard Captain.

After establishing a plan, they rested at the nearby Tavern, the Bustpick Inn and met Rufus, the owner.

Springing a trap, they managed to kill all but one of the goblins within mouth of mine, taking him hostage.

Extorting the goblin, they gathered information about what lied deeper within the cave.


#players






