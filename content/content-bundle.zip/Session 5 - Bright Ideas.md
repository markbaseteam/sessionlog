**Session 5 - Bright Ideas**
*20th-21st of Luck, Year 937*

Upon reaching the entrance to the caverns that lead, they found it fortified with some stonework walls.

After discussing with the general, he offered a squad to go with them, 4 stone guard and 2 Kavalrachni

Descending into the sloped tunnels, some of the party slid down the harsh slant while others took a more cautious path down.

After around 30 minutes, the party met at the bottom of the decent filled with 5 tunnels leading away, discovering a dead mindflayer and a Quaggoth down one of them.

Down another, they noticed a pack of Quaggoth's closing in, upon initiating combat, they sealed most of the tunnel and blocked the remainder with a Portable Hut spell, finishing off the rest of the Quaggoths.

The party split up, [[Don A. Shello - Brandon]] & [[Korrack Stonefury - Bradley]] took the standard entrance into the mindflayer colony, taking 4 Stoneguard and 1 of the Kavalrachni with them. Group A

In the meantime [[Harrison Pendlefoot - Teej]] & [[Pander Thistlebrow - Brendon]] descended down a deep tunnel with one of the Kavalrachni, about 500ft, one of the Mindflayer escape tunnels. Group B

**Group A -**
Going past the Guardroom & Common Room, they made their way into the Illithid Quarters, coming upon a room filled with Arcane research and books. Within they found a Merregon terrorizing a Kenku locked in a cage. Putting the Merregon to sleep, they broke the Kenku out of the cage and managed to find 3 magic scrolls around the room before exiting.

They about 300ft or so from the Elderbrain Chamber, having just exited back into the Common Room.

**Group B -**
When they descended the tunnel, they found it opened up into the Elderbrain Chamber, seeing that the shield meant to protect the Elderbrain had been shattered, the inside of it splattered with blood and pieces of brain. Floating infront of it was a Pale Mindflayer, using it's psyonic abilities to telepathically read the mind of Harrison Pendlefoot.

Co-ercing Harrison, offering some of the riches in the ruined colony, Harrison turned against the Kavalrachni, managing to knock the Steeder unconcious before being reduced to 0hp himself. Pander took this opportunity to catch the mindflayer by surprise, initiating combat with the pale Mindflayer. The Steeder Rider is still alive.



